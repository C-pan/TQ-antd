import React, { Component } from 'react'; 
import '../../style/common.css'

export default class Home extends React.Component{
    render(){
        return(
            <div className="content-box">
                <h1>login  </h1> 
            </div>
        )
    }
}