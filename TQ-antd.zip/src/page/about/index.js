import React, { Component } from 'react'; 
import { HashRouter, Router, Route, Link } from "react-router-dom";
import '../../style/common.css'
export default class About extends React.Component{
    render(){
        return(
            <div className="content-box">
                <h1>about  </h1> 
            </div>
        )
    }
}