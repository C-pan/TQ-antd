import React from 'react'; 
import { Link } from 'react-router-dom'
import './index.css'; 

export default class Header extends React.Component {
     render(){
          
         return(
             <div className="footer-box">
                  版权所有：Copyright © 2017 深圳市百特菲电子有限公司 All Rights Reserved | 备案号粤ICP备17152053号
             </div>
         )
     }
}
